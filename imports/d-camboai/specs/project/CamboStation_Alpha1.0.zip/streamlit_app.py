import streamlit as st

# Add this import 👇 to pull in your technicals panel
from app import ta_core

st.set_page_config(layout="wide")
st.title("CamboStation™ VISION-X")
st.markdown("Trade with Vision · Learn with Purpose · Evolve with AI")

tabs = ["📊 Technicals", "📈 Patterns", "🕯️ Candlesticks", "💬 Sentiment", "🧪 Scanners", "📘 Education"]
choice = st.sidebar.radio("Select Module", tabs)

if choice == "📊 Technicals":
    ta_core.show()
else:
    st.info(f"{choice} module not wired in yet — coming soon.")
