import streamlit as st
import yfinance as yf
import pandas_ta as ta
import plotly.graph_objects as go

def load_data(ticker, period="3mo", interval="1d"):
    return yf.download(ticker, period=period, interval=interval, auto_adjust=False)


def plot_chart(df, indicators):
    fig = go.Figure()

    # Candlestick base
    fig.add_trace(go.Candlestick(
        x=df.index,
        open=df["Open"],
        high=df["High"],
        low=df["Low"],
        close=df["Close"],
        name="Candles"
    ))

    # RSI Overlay
    if "RSI" in indicators:
        rsi = ta.rsi(df["Close"])
        if rsi is not None and not rsi.empty:
            fig.add_trace(go.Scatter(
                x=df.index,
                y=rsi,
                name="RSI",
                line=dict(color="purple")
            ))
        else:
            st.warning("⚠️ RSI data not available.")

    # MACD Overlay
    if "MACD" in indicators:
        macd = ta.macd(df["Close"])
        if macd is not None and not macd.empty:
            fig.add_trace(go.Scatter(
                x=df.index,
                y=macd["MACD_12_26_9"],
                name="MACD",
                line=dict(color="orange")
            ))
            fig.add_trace(go.Scatter(
                x=df.index,
                y=macd["MACDs_12_26_9"],
                name="Signal",
                line=dict(color="blue", dash="dot")
            ))
        else:
            st.warning("⚠️ MACD calculation returned no data. Try a longer time range or different ticker.")

    st.plotly_chart(fig, use_container_width=True)

def show():
    st.header("📊 Technical Indicator Panel")
    ticker = st.text_input("Enter Ticker", value="AAPL")
    indicators = st.multiselect("Select Indicators", ["RSI", "MACD"])
    if st.button("Load Chart"):
        df = load_data(ticker)
        plot_chart(df, indicators)
