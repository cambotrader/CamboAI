import os

CORE_FOLDERS = [
    "app", "assets/patterns", "assets/strategies", "utils", "docs"
]

FILES = {
    "requirements.txt": "streamlit\npandas\nyfinance\nplotly\n",
    "streamlit_app.py": '''import streamlit as st

st.set_page_config(layout="wide")
st.title("CamboStation™ VISION-X")
st.markdown("Trade with Vision · Learn with Purpose · Evolve with AI")

tabs = ["📊 Technicals", "📈 Patterns", "🕯️ Candlesticks", "💬 Sentiment", "🧪 Scanners", "📘 Education"]
choice = st.sidebar.radio("Select Module", tabs)
st.info(f"You selected: {choice}")
''',
    "README.md": "# CamboStation™ VISION-X\n\nRun this project with:\n\npip install -r requirements.txt\nstreamlit run streamlit_app.py\n"
}

def write_structure():
    for folder in CORE_FOLDERS:
        os.makedirs(folder, exist_ok=True)
    for path, content in FILES.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
    print("✅ CamboStation core structure created.")

if __name__ == "__main__":
    write_structure()
